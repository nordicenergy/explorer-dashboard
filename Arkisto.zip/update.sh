#!/bin/bash
git pull
npm run build
npm run serve
